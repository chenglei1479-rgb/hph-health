import { PackageFileOpenRelay, packagePathsFromArgv } from './session-package/file-open'
import { configureCredentialStore, getCredentialStore } from './settings/credential-store-mode'
import {
  selectStartupCredentialIdentity,
  prepareCredentialValidation
} from './credential-identity/bootstrap'
import { CredentialIdentityError } from './credential-identity/selection'
import { credentialRecoveryMessage } from './credential-identity/recovery'
import { parseWebModeOptions } from './web-service/options'
import { createRequire } from 'node:module'
import { basename, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { resolveBootstrapConfigRoot, resolveElectronProfile } from './storage/electron-profile'

// Only lightweight, Electron-free bootstrap modules are imported statically here. The MCP server
// modules (and their heavy SDK graph) remain lazy inside the matching execution branch.
import {
  ARTIFACT_MCP_SERVER_ARG,
  NOTEBOOK_MCP_SERVER_ARG,
  PLAN_MCP_SERVER_ARG,
  REVIEWER_MCP_PROXY_ARG,
  SKILL_IMPORT_MCP_SERVER_ARG,
  SKILL_RUNTIME_MCP_SERVER_ARG
} from './mcp-server-args'
import { createApplicationLifecycleShutdown } from './application-runtime'
import { installChildProcessGoneLogging, startLocalCrashReporting } from './crash-diagnostics'
import type { DiagnosticOperation } from './diagnostics/operation'
import {
  initializeApplicationDiagnostics,
  reportApplicationStartupFailure
} from './diagnostics/startup'
import {
  createLogger,
  diagnosticErrorFields,
  errorLogFields,
  flushLogs,
  writeFatalLogSync
} from './logger'
import { MANAGED_PREVIEW_SCHEME } from './managed-preview-resources'
import { OFFICE_PREVIEW_RUNTIME_SCHEME_CONFIG } from './office-preview/office-preview-runtime-protocol'
import {
  createRendererFailureReporter,
  registerRendererDiagnosticsIpc
} from './renderer-diagnostics'
import type {
  BaseWindow,
  BrowserWindow,
  Menu,
  MenuItem,
  MenuItemConstructorOptions
} from 'electron'
import type { InterfaceScaleShortcut } from '../shared/interface-scale'

const APP_NAME = 'Deep Research Agent'
const APP_USER_MODEL_ID = 'com.aipoch.medresearch-agent'
const shouldRunArtifactMcpServer = process.argv.includes(ARTIFACT_MCP_SERVER_ARG)
const shouldRunNotebookMcpServer = process.argv.includes(NOTEBOOK_MCP_SERVER_ARG)
const shouldRunReviewerMcpProxy = process.argv.includes(REVIEWER_MCP_PROXY_ARG)
const shouldRunSkillImportMcpServer = process.argv.includes(SKILL_IMPORT_MCP_SERVER_ARG)
const shouldRunSkillRuntimeMcpServer = process.argv.includes(SKILL_RUNTIME_MCP_SERVER_ARG)
const shouldRunPlanMcpServer = process.argv.includes(PLAN_MCP_SERVER_ARG)
const bootstrapLog = createLogger('bootstrap')
let credentialRecoveryPresented = false
let electronInitializationStarted = false
let preparingLocations = false
let bootstrapPhase = 'electron-bootstrap'
let startupDiagnostics: DiagnosticOperation | undefined
let startupFlush: import('./diagnostics/flush').DiagnosticFlush = flushLogs

const shortcutForZoomMenuRole = (role: string | undefined): InterfaceScaleShortcut | undefined => {
  switch (role?.toLowerCase()) {
    case 'zoomin':
      return 'increase'
    case 'zoomout':
      return 'decrease'
    case 'resetzoom':
      return 'reset'
    default:
      return undefined
  }
}

const menuItemToConstructorOptions = (item: MenuItem): MenuItemConstructorOptions => ({
  ...(item.role ? { role: item.role as MenuItemConstructorOptions['role'] } : { type: item.type }),
  ...(item.type !== 'separator' ? { label: item.label } : {}),
  ...(item.accelerator ? { accelerator: item.accelerator } : {}),
  enabled: item.enabled,
  visible: item.visible,
  ...(item.type === 'checkbox' || item.type === 'radio' ? { checked: item.checked } : {}),
  registerAccelerator: item.registerAccelerator,
  ...(item.submenu ? { submenu: item.submenu.items.map(menuItemToConstructorOptions) } : {}),
  ...(item.click && !item.role ? { click: item.click as MenuItemConstructorOptions['click'] } : {})
})

const buildZoomSafeApplicationMenu = (
  applicationMenu: Menu | null,
  MenuConstructor: typeof import('electron').Menu,
  isMainWindow: (window: BrowserWindow) => boolean,
  applyInterfaceScaleShortcut: (
    webContents: Pick<BrowserWindow['webContents'], 'getZoomFactor' | 'setZoomFactor' | 'send'>,
    shortcut: InterfaceScaleShortcut
  ) => void
): Menu | undefined => {
  if (!applicationMenu) return undefined

  const template: MenuItemConstructorOptions[] = applicationMenu.items.map((item) => {
    if (item.role?.toLowerCase() !== 'viewmenu' || !item.submenu)
      return menuItemToConstructorOptions(item)

    const submenu = MenuConstructor.buildFromTemplate(
      item.submenu.items.map((viewItem) => {
        const shortcut = shortcutForZoomMenuRole(viewItem.role)
        if (!shortcut) return menuItemToConstructorOptions(viewItem)

        return {
          label: viewItem.label,
          accelerator: viewItem.accelerator ?? undefined,
          click: (_menuItem: MenuItem, focusedWindow?: BaseWindow) => {
            if (!focusedWindow) return
            const browserWindow = focusedWindow as BrowserWindow

            if (isMainWindow(browserWindow)) {
              applyInterfaceScaleShortcut(browserWindow.webContents, shortcut)
              return
            }

            const webContents = browserWindow.webContents
            if (shortcut === 'reset') {
              webContents.setZoomLevel(0)
            } else {
              // Electron's zoomIn/zoomOut roles advance by 10%, which is half a Chromium
              // zoom level. Keep secondary windows aligned with their native menu behavior.
              const direction = shortcut === 'increase' ? 0.5 : -0.5
              webContents.setZoomLevel(webContents.getZoomLevel() + direction)
            }
          }
        }
      })
    )

    return {
      label: item.label,
      submenu
    }
  })

  return MenuConstructor.buildFromTemplate(template)
}

if (shouldRunArtifactMcpServer) {
  // Reuse the packaged entry point as a Node stdio MCP server; import it only in this mode.
  void import('./artifacts/mcp-server')
    .then(({ runArtifactMcpServer }) => runArtifactMcpServer())
    .catch((error: unknown) => {
      bootstrapLog.error('artifact MCP server failed', error)
      process.exitCode = 1
    })
} else if (shouldRunNotebookMcpServer) {
  // Keep notebook MCP mode as a Node stdio process that proxies to the app-owned runtime.
  void import('./notebook/mcp-server')
    .then(({ runNotebookMcpServer }) => runNotebookMcpServer())
    .catch((error: unknown) => {
      bootstrapLog.error('notebook MCP server failed', error)
      process.exitCode = 1
    })
} else if (shouldRunReviewerMcpProxy) {
  void import('./reviewer/mcp-stdio-proxy')
    .then(({ runReviewerMcpStdioProxy }) => runReviewerMcpStdioProxy())
    .catch((error: unknown) => {
      bootstrapLog.error('reviewer MCP proxy failed', error)
      process.exitCode = 1
    })
} else if (shouldRunSkillImportMcpServer) {
  void import('./skills/mcp-server')
    .then(({ runSkillImportMcpServer }) => runSkillImportMcpServer())
    .catch((error: unknown) => {
      bootstrapLog.error('skill import MCP server failed', error)
      process.exitCode = 1
    })
} else if (shouldRunSkillRuntimeMcpServer) {
  void import('./skills/runtime-mcp-server')
    .then(({ runSkillRuntimeMcpServer }) => runSkillRuntimeMcpServer())
    .catch((error: unknown) => {
      bootstrapLog.error('skill runtime MCP server failed', error)
      process.exitCode = 1
    })
} else if (shouldRunPlanMcpServer) {
  void import('./session-plan/plan-mcp-server')
    .then(({ runPlanMcpServer }) => runPlanMcpServer())
    .catch((error: unknown) => {
      bootstrapLog.error('plan MCP server failed', error)
      process.exitCode = 1
    })
} else {
  void startElectronApp(fileURLToPath(import.meta.url)).catch(async (error: unknown) => {
    // Emit before native recovery UI: pre-ready failures may never reach a window or file sink.
    // Reuse the bounded secret-redacting formatter, while retaining the credential reason code.
    bootstrapLog.error('application startup failed', {
      ...diagnosticErrorFields(error),
      ...errorLogFields(error),
      phase: bootstrapPhase,
      ...(error instanceof CredentialIdentityError
        ? {
            recoveryReason: error.reason,
            ...(error.probe ? { identityProbe: error.probe } : {})
          }
        : {})
    })
    const { app, dialog } = createRequire(import.meta.url)('electron') as typeof import('electron')
    if (error instanceof CredentialIdentityError) {
      if (!credentialRecoveryPresented) {
        credentialRecoveryPresented = true
        const message = credentialRecoveryMessage(error, app.getPreferredSystemLanguages())
        // A headless launch (web service, packaged smoke) has no one to dismiss a modal; a
        // blocking box hangs an unattended run instead of failing it, so recovery goes to stderr.
        if (parseWebModeOptions(process.argv).headless)
          process.stderr.write(`${APP_NAME}: ${message}\n`)
        else dialog.showErrorBox(APP_NAME, message)
      }
      // Do not yield to Electron's profile/key initialization after a failed pre-ready probe.
      app.exit(1)
      return
    }
    // Location/configuration failures happen before file diagnostics and the renderer. Present
    // recovery before awaiting diagnostics; neither message wording nor a working file sink gates it.
    if (preparingLocations) {
      dialog.showErrorBox(APP_NAME, error instanceof Error ? error.message : String(error))
    }
    if (!electronInitializationStarted) {
      // Preflight failures must not yield to OSCrypt initialization, even for a configuration error.
      app.exit(1)
      return
    }
    await reportApplicationStartupFailure({
      operation: startupDiagnostics,
      error,
      flush: startupFlush
    })
    app.exit(1)
  })
}

// Boots the Electron app only in normal UI mode, keeping artifact MCP mode free of Electron imports.
async function startElectronApp(mainEntryPath: string): Promise<void> {
  const {
    app,
    BrowserWindow,
    crashReporter,
    ipcMain,
    nativeImage,
    nativeTheme,
    powerMonitor,
    protocol,
    safeStorage,
    dialog
  } = createRequire(import.meta.url)('electron') as typeof import('electron')

  let reportPackageOverflow = (): void => undefined
  const packageFiles = new PackageFileOpenRelay(() => reportPackageOverflow())
  app.on('open-file', (event, path) => {
    event.preventDefault()
    packageFiles.receive(path)
  })

  // Electron accepts privileged schemes only before app ready. Keep this in the synchronous UI
  // bootstrap before any awaited import can yield to the ready event.
  protocol.registerSchemesAsPrivileged([
    MANAGED_PREVIEW_SCHEME,
    OFFICE_PREVIEW_RUNTIME_SCHEME_CONFIG
  ])

  // Establish identity and single-writer ownership before opening main.log. A secondary launch must
  // never rotate or append to the primary process's file sink. These two modules are lightweight; all
  // backend imports remain behind the lock.
  // Electron captures the OSCrypt identity immediately after the synchronous main entry. The
  // metadata probe must finish before the first await, profile initialization, or secret access.
  bootstrapPhase = 'credential-store-mode'
  const webMode = parseWebModeOptions(process.argv)
  configureCredentialStore(process.argv, process.platform, webMode.headless)
  bootstrapPhase = 'credential-identity'
  const credentialIdentity = selectStartupCredentialIdentity({
    platform: process.platform,
    packaged: app.isPackaged,
    credentialStore: getCredentialStore(),
    ...(process.platform === 'linux'
      ? { linuxPasswordStore: app.commandLine?.getSwitchValue('password-store') }
      : {})
  })
  app.setName(credentialIdentity.appName)
  preparingLocations = true
  bootstrapPhase = 'configuration-root'
  const configRoot = resolveBootstrapConfigRoot(app.getPath('home'), app.isPackaged)
  bootstrapPhase = 'electron-profile'
  const profilePath = resolveElectronProfile({
    appData: app.getPath('appData'),
    configRoot,
    packaged: app.isPackaged
  })
  app.setPath('userData', profilePath)
  app.setPath('sessionData', profilePath)
  const isolated = Boolean(
    process.env.OPEN_SCIENCE_USER_DATA ||
    process.env.OPEN_SCIENCE_CONFIG_ROOT ||
    process.env.OPEN_SCIENCE_E2E_STORAGE_ROOT ||
    (!app.isPackaged && process.env.OPEN_SCIENCE_STORAGE_ROOT)
  )
  const allowMultiInstance =
    !app.isPackaged && process.env.OPEN_SCIENCE_ALLOW_MULTI_INSTANCE === '1'
  const pendingSecondInstances: Array<[string[], string]> = []
  let relaySecondInstance = (argv: string[], cwd: string): void => {
    pendingSecondInstances.push([argv, cwd])
  }
  if (!allowMultiInstance && !app.requestSingleInstanceLock()) {
    app.quit()
    return
  }
  app.on('second-instance', (_event, argv, cwd) => relaySecondInstance(argv, cwd))
  bootstrapPhase = 'credential-validation-preflight'
  const validateCredentials = prepareCredentialValidation(credentialIdentity, {
    configRoot,
    profilePath
  })
  // A real secret-read phase may request OS authorization. It is not part of the silent probe.
  // No settings recovery, database migration, or BrowserWindow can run before it succeeds.
  electronInitializationStarted = true
  bootstrapPhase = 'electron-ready'
  await app.whenReady()
  app.setName(app.isPackaged ? APP_NAME : `${APP_NAME} (DEV)`)
  bootstrapPhase = 'credential-ciphertext-validation'
  validateCredentials(safeStorage, (error) => {
    if (!credentialRecoveryPresented) {
      bootstrapLog.error('credential access failed', {
        recoveryReason: error.reason,
        ...(error.probe ? { identityProbe: error.probe } : {})
      })
      credentialRecoveryPresented = true
      const message = credentialRecoveryMessage(error, app.getPreferredSystemLanguages())
      // Same headless rule as the pre-ready recovery path: never block an unattended launch.
      if (webMode.headless) process.stderr.write(`${APP_NAME}: ${message}\n`)
      else dialog.showErrorBox(APP_NAME, message)
    }
    app.exit(1)
  })
  bootstrapPhase = 'application-initialization'
  app.setAppLogsPath(
    process.platform === 'darwin' && !isolated
      ? join(app.getPath('home'), 'Library', 'Logs', basename(profilePath))
      : join(profilePath, 'logs')
  )
  const [
    {
      createSecondInstanceRelay,
      createStartupWindowCloseOptions,
      createStartupWindowSecondInstanceHandler,
      orchestrateAppStartup,
      prepareVisibleStartupRuntime,
      waitForStartupShell
    },
    { installSystemLifecycleAdapters }
  ] = await Promise.all([import('./app-startup'), import('./system-lifecycle-adapters')])
  const preStartupSecondInstanceRelay = createSecondInstanceRelay()
  relaySecondInstance = (argv, cwd) => {
    for (const path of packagePathsFromArgv(argv, cwd)) packageFiles.receive(path)
    preStartupSecondInstanceRelay.signal(argv)
  }
  for (const [argv, cwd] of pendingSecondInstances) relaySecondInstance(argv, cwd)
  for (const path of packagePathsFromArgv(process.argv, process.cwd())) packageFiles.receive(path)
  const { prepareApplicationLocations } = await import('./storage/initialize-location')
  bootstrapPhase = 'initialize-application-locations'
  const bootstrapLocations = await prepareApplicationLocations(configRoot)
  preparingLocations = false
  let bindSystemShutdownWindow = (window: InstanceType<typeof BrowserWindow>): void => {
    void window
  }
  let installPowerMonitorListeners = (): void => {}

  // Initialize the file sink after credential validation but before assets and the backend graph
  // so later packaged startup failures remain locally diagnosable.
  bootstrapPhase = 'application-diagnostics'
  const diagnostics = initializeApplicationDiagnostics({
    logDir: app.getPath('logs'),
    version: app.getVersion(),
    isPackaged: app.isPackaged,
    platform: process.platform,
    arch: process.arch,
    electronVersion: process.versions.electron,
    nodeVersion: process.versions.node,
    cpuUsage: process.cpuUsage
  })
  const { log } = diagnostics
  startupDiagnostics = diagnostics.operation
  startupFlush = diagnostics.flush
  // Disk classification is diagnostic only. Do not await it on the path to failure capture,
  // bootstrap assets, or the first window; log the result whenever the probe settles.
  void import('./diagnostics/startup-storage-probe')
    .then(({ timedStartupStorageProbe }) =>
      timedStartupStorageProbe({ probeDir: app.getPath('logs') }, 1_500)
    )
    .then((storageProbe) => {
      log.info('startup storage probe', storageProbe)
    })
    .catch(() => undefined)

  // Register process-level failure capture before loading the application modules. Keep renderer
  // diagnostics on a separate, one-way channel while the central IPC registry is being refactored.
  installChildProcessGoneLogging((listener) => app.on('child-process-gone', listener), log)
  // Observe fatal JavaScript failures without consuming Node's default non-zero termination. A
  // consuming uncaughtException/unhandledRejection listener would leave Electron serving IPC and
  // mutating durable state after application invariants became unknown. The monitor also receives
  // unhandled rejections promoted by Node's default `throw` mode, preserving their distinct origin.
  process.on('uncaughtExceptionMonitor', (error, origin) =>
    writeFatalLogSync('main', origin, diagnosticErrorFields(error))
  )
  registerRendererDiagnosticsIpc(
    ipcMain,
    createRendererFailureReporter({ log: createLogger('renderer') })
  )

  startupDiagnostics.phase('load-bootstrap-modules')
  const [
    { electronApp },
    { default: appIconPng },
    { default: appIconDarkPng },
    { default: appIconIco },
    { default: appIconDarkIco },
    { default: trayMacTemplate },
    { default: trayLightWindows },
    { default: trayDarkWindows },
    { default: trayLinux }
  ] = await Promise.all([
    import('@electron-toolkit/utils'),
    import('../../resources/icon.png?asset'),
    import('../../resources/icon-dark.png?asset'),
    import('../../resources/icon-light.ico?asset'),
    import('../../resources/icon-dark.ico?asset'),
    import('../../resources/trayTemplate.png?asset'),
    import('../../resources/tray-light.ico?asset'),
    import('../../resources/tray-dark.ico?asset'),
    import('../../resources/tray.png?asset')
  ])

  // Light and dark surfaces use the same dotted-ring mark on theme-matched backgrounds.
  const iconVariantPaths =
    process.platform === 'win32'
      ? { light: appIconIco, dark: appIconDarkIco }
      : { light: appIconPng, dark: appIconDarkPng }
  const trayIconPath =
    process.platform === 'win32'
      ? trayLightWindows
      : process.platform === 'linux'
        ? trayLinux
        : appIconPng
  const trayVariantIconPaths =
    process.platform === 'win32'
      ? { light: trayLightWindows, dark: trayDarkWindows }
      : process.platform === 'linux'
        ? { light: appIconPng, dark: appIconDarkPng }
        : undefined

  // Ordered startup: the single-instance lock is acquired FIRST (UI path only — the MCP stdio server
  // modes never reach startElectronApp), so a secondary launch quits before prepare() imports any
  // backend module or spawns a duplicate process tree. prepare() then does the heavy post-lock work and
  // returns the handles the migration guard and lifecycle need; the guard is installed before the
  // lifecycle so its before-quit runs first. A second launch that arrives mid-startup is recorded by the
  // relay and surfaced once the window exists.
  let openPackageWindow: (() => void) | undefined
  let forwardSecondInstanceDuringStartup: ((argv: string[]) => void) | undefined
  bootstrapPhase = 'application-startup'
  await orchestrateAppStartup({
    diagnostics: startupDiagnostics,
    // The OS lock is already held. Bind the orchestrator's relay to the pre-logger relay so any
    // second-instance signal received during bootstrap is preserved until the lifecycle is ready.
    acquireSingleInstanceLock: ({ onSecondInstance }) => {
      forwardSecondInstanceDuringStartup = onSecondInstance
      preStartupSecondInstanceRelay.bind(onSecondInstance)
      return true
    },
    quit: () => app.quit(),
    forceExit: () => app.exit(0),
    installSystemShutdownListeners: (requestSystemShutdown) => {
      const adapters = installSystemLifecycleAdapters({
        windowSessionEndEvents: process.platform === 'win32',
        powerShutdownEvent: process.platform !== 'win32',
        headless: webMode.headless,
        signalSource: process,
        powerMonitor,
        getWindows: () => BrowserWindow.getAllWindows(),
        requestSystemShutdown
      })
      bindSystemShutdownWindow = adapters.bindWindow
      installPowerMonitorListeners = adapters.installPowerMonitorListeners
    },
    prepare: async () => {
      // Start local-only Crashpad after the single-instance lock but before any BrowserWindow can
      // create a renderer. Upload stays disabled: dumps remain local for explicit support collection.
      // Without this initialization, native failures can terminate a process without leaving the dump
      // needed to distinguish a renderer, utility, or main-process crash.
      const crashReporting = startLocalCrashReporting({
        platform: process.platform,
        productName: APP_NAME,
        companyName: 'aipoch',
        appVersion: app.getVersion(),
        start: (options) => crashReporter.start(options)
      })
      startupDiagnostics?.phase('crash-reporting', { enabled: crashReporting.enabled })

      startupDiagnostics?.phase('electron-ready')
      await app.whenReady()
      app.setName(app.isPackaged ? APP_NAME : `${APP_NAME} (DEV)`)
      // Electron created its default menu before ready using the selected credential identity.
      // Rebuild standard roles after the display brand is known.
      const { Menu } = createRequire(import.meta.url)('electron') as typeof import('electron')
      installPowerMonitorListeners()

      startupDiagnostics?.phase('load-startup-shell-modules')
      const [
        { createManagedPreviewProtocolBridge },
        { configureMainWindow, createMainWindow, isMainWindow },
        { LocalePreferenceOwner },
        { registerLocalePreferenceIpc },
        { applyInterfaceScaleShortcut, installWindowShortcuts },
        { registerWindowZoomIpcHandler },
        { registerNetworkIpcHandlers },
        { createDatabaseStartupLogging },
        { createDatabaseStartupOwner },
        { installDatabaseStartupQuitGuard, registerDatabaseStartupIpc },
        { buildStartupDiagnostics },
        { getProjectDbClient },
        { resolveConfigRoot },
        { initializeDataLocation }
      ] = await Promise.all([
        import('./managed-preview-protocol'),
        import('./windows'),
        import('./locale/owner'),
        import('./locale/ipc'),
        import('./window-shortcuts'),
        import('./window-ipc'),
        import('./network-ipc'),
        import('./database/database-startup-logging'),
        import('./database/database-startup-owner'),
        import('./database/database-startup-ipc'),
        import('./database/startup-diagnostics'),
        import('./projects/prisma-client'),
        import('./storage-root'),
        import('./storage/initialize-location')
      ])

      if (process.platform === 'darwin') {
        Menu.setApplicationMenu(
          Menu.buildFromTemplate([
            { role: 'appMenu' },
            { role: 'fileMenu' },
            { role: 'editMenu' },
            { role: 'viewMenu' },
            { role: 'windowMenu' },
            { role: 'help', submenu: [] }
          ])
        )
      }

      const zoomSafeApplicationMenu = buildZoomSafeApplicationMenu(
        Menu.getApplicationMenu?.() ?? null,
        Menu,
        isMainWindow,
        applyInterfaceScaleShortcut
      )
      if (zoomSafeApplicationMenu) Menu.setApplicationMenu(zoomSafeApplicationMenu)

      startupDiagnostics?.phase('prepare-shell')
      // The bridge is lightweight, but its protocol handler must exist before the first BrowserWindow
      // creates the default session. macOS otherwise treats later managed-preview requests as an
      // unknown scheme even though the privileged scheme itself was registered before app ready.
      const managedPreviewProtocolBridge = createManagedPreviewProtocolBridge(protocol)
      // Create the settings document owner before any native surface. The startup locale repository
      // and the later application Settings repository share this store, so every settings.json
      // mutation uses one serialization queue and one atomic-write implementation.
      const settingsStore = bootstrapLocations.settingsStore
      const startupSettingsRepository = bootstrapLocations.repository
      await initializeDataLocation(startupSettingsRepository)
      const startupSettings = await startupSettingsRepository.getSettings()
      const localeOwner = new LocalePreferenceOwner(
        app.getPreferredSystemLanguages(),
        startupSettingsRepository,
        startupSettings.localePreference
      )
      const translate = localeOwner.t.bind(localeOwner)
      const disposeLocalePreferenceIpc = registerLocalePreferenceIpc(localeOwner)

      // Set app user model id for windows
      electronApp.setAppUserModelId(APP_USER_MODEL_ID)

      // Main-window zoom shortcuts share Settings' Electron zoom factor; secondary windows retain
      // their native menu accelerators. The optimizer still handles its other standard shortcuts.
      installWindowShortcuts(app, undefined, isMainWindow)
      // The renderer applies its persisted interface scale before the full application runtime is
      // composed. Install this small handler before creating the first BrowserWindow so that the
      // initial renderer call cannot race the desktop utility surface.
      registerWindowZoomIpcHandler()

      const databaseStartupLogging = createDatabaseStartupLogging(log, app.getVersion())
      const databaseStartupOwner = createDatabaseStartupOwner({
        reportBlocked: databaseStartupLogging.reportBlocked,
        buildDiagnostics: (error) =>
          buildStartupDiagnostics(error, {
            configRoot: resolveConfigRoot(),
            dataRoot: startupSettings.dataRoot
          }),
        environment: {
          appVersion: app.getVersion(),
          platform: process.platform,
          arch: process.arch,
          electron: process.versions.electron ?? 'unknown',
          node: process.versions.node ?? 'unknown'
        },
        verifyDatabase: async (onProgress) => {
          await getProjectDbClient(
            resolveConfigRoot(),
            databaseStartupLogging.migrationOptions(onProgress)
          )
        }
      })
      const startupWindowCloseOptions = createStartupWindowCloseOptions(() => app.quit())
      // The renderer probes connectivity as soon as it mounts, before the full application runtime
      // is composed. Install these handlers before creating the first BrowserWindow so that startup
      // probe cannot race the desktop utility adapter installation.
      registerNetworkIpcHandlers()
      const disposeDatabaseStartupIpc = registerDatabaseStartupIpc({
        ipcMain,
        owner: databaseStartupOwner,
        quit: startupWindowCloseOptions.requestQuit,
        getWindows: () => BrowserWindow.getAllWindows()
      })
      const databaseStartupQuitGuard = installDatabaseStartupQuitGuard({
        app,
        owner: databaseStartupOwner
      })
      const startupWindow = webMode.headless
        ? undefined
        : createMainWindow(startupWindowCloseOptions, translate)
      if (startupWindow) bindSystemShutdownWindow(startupWindow)
      // Yield the main-process event loop until Chromium has painted the startup shell. Evaluating the
      // 5 MB backend chunk immediately after BrowserWindow construction can otherwise delay
      // ready-to-show even though the window no longer depends on that chunk.
      const startupShellRendered = startupWindow
        ? waitForStartupShell(startupWindow, { diagnostics: startupDiagnostics })
        : Promise.resolve()
      if (startupWindow) {
        void startupShellRendered
          .then(async () => {
            const { isReadOnlyMacInstallation, showMacInstallationGuidance } =
              await import('./mac-installation')
            if (isReadOnlyMacInstallation()) void showMacInstallationGuidance('startup')
          })
          .catch(() => {})
        if (!forwardSecondInstanceDuringStartup) {
          throw new Error('Second-instance startup relay is not initialized.')
        }
        preStartupSecondInstanceRelay.bind(
          createStartupWindowSecondInstanceHandler(
            startupWindow,
            forwardSecondInstanceDuringStartup
          )
        )
      }

      startupDiagnostics?.phase('database-and-application-modules')
      const initialDatabaseAttempt = databaseStartupOwner.start()
      return prepareVisibleStartupRuntime({
        // The shell and its first BrowserWindow already exist before this orchestration begins. The
        // async seam keeps the ordering explicit and lets database verification and backend loading
        // start together on the next step.
        prepareShell: async () => undefined,
        verifyDatabase: async () => {
          if (webMode.headless) {
            const state = await initialDatabaseAttempt
            if (state.phase === 'blocked') {
              throw Object.assign(new Error(state.error.message), state.error)
            }
            return
          }
          await Promise.race([
            databaseStartupOwner.whenVerified(),
            initialDatabaseAttempt.then((state) =>
              state.phase === 'blocked' ? new Promise<void>(() => undefined) : undefined
            )
          ])
        },
        loadApplicationModules: async () => {
          await startupShellRendered
          startupDiagnostics?.phase('load-application-modules')
          const loaded = await Promise.all([
            import('./ipc'),
            import('./storage/migration-state'),
            import('./tray'),
            import('./app-lifecycle'),
            import('./ipc-handler-registry'),
            import('./web-service'),
            import('./second-instance-router'),
            import('./window-close-confirm'),
            import('./session-persistence/renderer-flush'),
            import('./app-icon'),
            import('./remote-access'),
            import('./notifications/desktop-attention'),
            import('./notifications/desktop-badge'),
            import('./notifications/notification-inbox-controller'),
            import('./notifications/unread-task-ipc')
          ])
          startupDiagnostics?.phase('application-modules-loaded')
          return loaded
        },
        composeRuntime: async (
          _,
          [
            { registerIpcHandlers },
            { installMigrationQuitGuard, isMigrationInProgress },
            { createAppTray, refreshAppTrayLocale, setTrayIconVariant },
            { installAppLifecycle },
            { disposeIpcHandlerRegistry },
            { createWebServiceController, buildAuthenticatedWebUrl },
            { routeSecondInstance },
            { createElectronCloseConfirm },
            {
              createElectronSessionPersistenceFlush,
              notifyRendererSessionPersistenceFlushAborted,
              rendererSessionPersistenceFlushBlocksShutdown
            },
            { createAppIconController, buildAppIconPreviews },
            { RemoteAccessService, registerRemoteAccessIpcHandlers },
            { createDesktopAttentionController, wireDesktopAttention },
            { createDesktopBadgeAdapter, createWindowsBadgeBitmap },
            { wireNotificationInboxController },
            { registerUnreadTaskIpc }
          ]
        ) => {
          startupDiagnostics?.phase('compose-runtime')
          // Retain ownership before the complete context can be handed to the lifecycle.
          let disposePartialRuntime:
            Awaited<ReturnType<typeof registerIpcHandlers>>['dispose'] | undefined
          let partialRemoteAccess:
            Awaited<ReturnType<typeof RemoteAccessService.create>> | undefined
          let partialWebController: ReturnType<typeof createWebServiceController> | undefined
          let disposeTrayLocaleSubscription: (() => void) | undefined

          // The controller must exist before its IPC responder, while the responder calls back into the
          // controller. This box breaks that startup cycle without exposing unread ownership to renderer.
          const visibilityProbeBox: {
            current: ReturnType<typeof registerUnreadTaskIpc> | undefined
          } = { current: undefined }

          try {
            startupDiagnostics?.phase('register-application-ipc')
            // Held in a box (not a bare let) so the settings IPC callback registered below can reach the icon
            // controller, which itself needs the persisted variant that only exists once settingsService is
            // constructed. The change callback only fires on a user action (well after startup), so the
            // controller is always set by then. Mirrors the trayBox late-binding pattern in app-lifecycle.ts.
            const appIconControllerBox: {
              current: ReturnType<typeof createAppIconController> | undefined
            } = { current: undefined }
            // Late-bound tray handle so the settings IPC below can restyle the tray when the user switches
            // the app icon variant — the tray only exists once the lifecycle is installed (assigned in the
            // createTray callback). Mirrors the trayBox late-binding pattern in app-lifecycle.ts.
            const appTrayBox: { current: ReturnType<typeof createAppTray> } = { current: undefined }
            disposeTrayLocaleSubscription = localeOwner.subscribe(() =>
              refreshAppTrayLocale(appTrayBox.current)
            )
            // Unread state restores before the main-window lifecycle is installed. Late-bind its getter so
            // restoration remains window-independent while later badge/probe calls always target the live window.
            const mainWindowGetterBox: {
              current: (() => InstanceType<typeof BrowserWindow> | undefined) | undefined
            } = { current: undefined }

            // Pass the concrete main entry path so ACP can launch the artifact MCP server from the same bundle.
            const {
              openSessionPackageFile,
              applicationCommands,
              applicationEvents,
              permissionApprovalPresence,
              bindRemoteAccess,
              taskNotifications,
              notificationInbox,
              settingsService,
              commitClosePreference,
              taskAgent,
              taskControls,
              computePreferences,
              detectActiveSessions,
              hasActiveReviewerWork,
              getActiveSettingsInstallId,
              holdSettingsInstallAdmission,
              prepareForQuit,
              abortQuitPreparation,
              dispose: disposeRuntime
            } = await registerIpcHandlers({
              mainEntryPath,
              settingsStore,
              translate,
              managedPreviewProtocol: managedPreviewProtocolBridge.registrar,
              handoffRuntime: 'production',
              headless: webMode.headless,
              confirmRendererDurability: async (policy) => {
                const getWindow = (): InstanceType<typeof BrowserWindow> | undefined =>
                  mainWindowGetterBox.current?.()
                const outcome = await createElectronSessionPersistenceFlush(getWindow)()
                if (!rendererSessionPersistenceFlushBlocksShutdown(outcome, policy)) {
                  return true
                }
                notifyRendererSessionPersistenceFlushAborted(getWindow)
                return false
              },
              notifyRendererDurabilityAborted: () =>
                notifyRendererSessionPersistenceFlushAborted(() => mainWindowGetterBox.current?.()),
              onAppIconVariantChanged: (variant) => {
                appIconControllerBox.current?.setVariant(variant)
              },
              listAppIconPreviews: () => buildAppIconPreviews(nativeImage, iconVariantPaths)
            })
            const disposeApplicationRuntime = (): ReturnType<typeof disposeRuntime> => {
              visibilityProbeBox.current?.dispose()
              return disposeRuntime()
            }
            disposePartialRuntime = disposeApplicationRuntime
            startupDiagnostics?.phase('compose-desktop-surfaces')

            notificationInbox.configureDesktop({
              // Only the main conversation window can acknowledge a visible session. A focused preview
              // window must not clear unread state for the conversation underneath it.
              isAppFocused: () => mainWindowGetterBox.current?.()?.isFocused() ?? false,
              confirmSessionVisible: (sessionId) =>
                visibilityProbeBox.current?.confirmSessionVisible(sessionId) ??
                Promise.resolve(false),
              badge: createDesktopBadgeAdapter({
                platform: process.platform,
                setBadgeCount: (count) => app.setBadgeCount(count),
                isUnityRunning: () => app.isUnityRunning(),
                getMainWindow: () => mainWindowGetterBox.current?.(),
                createWindowsOverlay: (label) =>
                  nativeImage.createFromBitmap(createWindowsBadgeBitmap(label), {
                    width: 16,
                    height: 16,
                    scaleFactor: 1
                  }),
                onError: (error) => log.warn('desktop unread badge failed', error)
              })
            })
            visibilityProbeBox.current = registerUnreadTaskIpc({
              getMainWindow: () => mainWindowGetterBox.current?.(),
              controller: notificationInbox,
              onError: (error) => log.warn('message center visibility IPC failed', error)
            })
            // Start with the OS day/night icon, then use the app's resolved theme after the renderer reports it.
            const initialVariant = nativeTheme.shouldUseDarkColors ? 'dark' : 'light'
            appIconControllerBox.current = createAppIconController({
              electron: {
                app,
                getAllWindows: () => BrowserWindow.getAllWindows(),
                nativeImage,
                nativeTheme
              },
              variantPaths: iconVariantPaths,
              initialVariant,
              onVariantChanged: (variant) => {
                if (appTrayBox.current && trayVariantIconPaths) {
                  setTrayIconVariant(appTrayBox.current, trayVariantIconPaths, variant)
                }
              }
            })
            startupDiagnostics?.phase('compose-remote-access')
            const remoteAccess = await RemoteAccessService.create()
            partialRemoteAccess = remoteAccess
            bindRemoteAccess(remoteAccess)
            const webController = createWebServiceController({
              applicationCommands,
              requestQuit: () => app.quit(),
              externalAccess: remoteAccess.webAccess,
              applicationEvents,
              permissionApprovalPresence,
              taskAgent,
              taskControls,
              computePreferences,
              detectActiveSessions
            })
            partialWebController = webController
            remoteAccess.attachWebController(webController)
            registerRemoteAccessIpcHandlers(remoteAccess)
            // A launch that itself requested serving (a dedicated headless daemon, or an explicit --serve) is
            // not attached: stopping it quits the process. On-demand starts for a running instance are attached.
            if (webMode.enabled)
              await webController.ensureStarted(webMode.port, { attached: false })
            // Restore a persisted remote-access preference only after the normal IPC/web surfaces exist.
            // A missing or signed-out third-party remote-access installation must never delay the desktop window.
            void remoteAccess.restore()

            const disposeApplicationIpcHandlers = (): void => {
              const failures: unknown[] = []
              for (const cleanup of [
                () => visibilityProbeBox.current?.dispose(),
                () => disposeTrayLocaleSubscription?.(),
                disposeLocalePreferenceIpc,
                () => managedPreviewProtocolBridge.dispose(),
                disposeDatabaseStartupIpc,
                disposeIpcHandlerRegistry
              ]) {
                try {
                  cleanup()
                } catch (error) {
                  failures.push(error)
                }
              }
              if (failures.length > 0) {
                throw new AggregateError(failures, 'Application IPC cleanup failed.')
              }
            }
            const shutdownApplicationSurfaces = createApplicationLifecycleShutdown({
              disposeApplicationRuntime,
              remoteAccess,
              webController,
              disposeIpcHandlers: disposeApplicationIpcHandlers,
              log
            })

            return {
              openSessionPackageFile,
              installMigrationQuitGuard,
              isMigrationInProgress,
              createMainWindow: (options: Parameters<typeof createMainWindow>[0]) =>
                createMainWindow(options, translate),
              configureMainWindow,
              startupWindow,
              createAppTray,
              translate,
              buildAuthenticatedWebUrl,
              routeSecondInstance,
              taskNotifications,
              notificationInbox,
              mainWindowGetterBox,
              settingsService,
              appIconControllerBox,
              appTrayBox,
              // Read through the controller (not a snapshot) so a tray created after a settings change —
              // e.g. a headless web client flipping the variant mid-startup — starts on the live value.
              getAppIconVariant: () => appIconControllerBox.current?.getVariant() ?? initialVariant,
              disposeApplicationRuntime,
              detectActiveSessions,
              hasActiveReviewerWork,
              getActiveSettingsInstallId,
              holdSettingsInstallAdmission,
              prepareForQuit,
              abortQuitPreparation,
              createSessionPersistenceFlush: (
                getWindow: () => InstanceType<typeof BrowserWindow> | undefined
              ) => createElectronSessionPersistenceFlush(getWindow),
              notifySessionPersistenceFlushAborted: (
                getWindow: () => InstanceType<typeof BrowserWindow> | undefined,
                reason?: Parameters<typeof notifyRendererSessionPersistenceFlushAborted>[1]
              ) => notifyRendererSessionPersistenceFlushAborted(getWindow, reason),
              createConfirmClose: (
                getWindow: () => InstanceType<typeof BrowserWindow> | undefined
              ) =>
                createElectronCloseConfirm(
                  getWindow,
                  {
                    get: () => settingsService.getClosePreference(),
                    set: async (preference) => {
                      await commitClosePreference(preference)
                    }
                  },
                  translate
                ),
              installAppLifecycle,
              createDesktopAttentionController,
              wireDesktopAttention,
              wireNotificationInboxController,
              log,
              webMode,
              webController,
              remoteAccess,
              shutdownApplicationSurfaces,
              databaseStartupOwner,
              databaseStartupQuitGuard
            }
          } catch (error) {
            // Invalidate caller leases immediately if composition fails after registering IPC. The
            // outer shell rollback destroys the window and quits, but renderer calls can still arrive
            // while that shutdown is in flight.
            for (const invalidate of [
              () => visibilityProbeBox.current?.dispose(),
              disposeIpcHandlerRegistry,
              () => managedPreviewProtocolBridge.dispose()
            ]) {
              try {
                invalidate()
              } catch {
                // Preserve the startup error and still stop all acquired services.
              }
            }
            await createApplicationLifecycleShutdown({
              disposeApplicationRuntime: () => disposePartialRuntime?.(),
              remoteAccess: { shutdown: () => partialRemoteAccess?.shutdown() },
              webController: { dispose: () => partialWebController?.dispose() },
              disposeIpcHandlers: () => disposeTrayLocaleSubscription?.(),
              log
            })()
            throw error
          }
        },
        rollbackShell: async () => {
          // Module loading can fail while verification is actively migrating. Keep the quit guard
          // installed until that attempt settles so app.quit cannot interrupt database writes.
          await databaseStartupOwner.whenAttemptSettled()
          for (const cleanup of [
            disposeLocalePreferenceIpc,
            () => databaseStartupQuitGuard.dispose(),
            () => managedPreviewProtocolBridge.dispose(),
            disposeDatabaseStartupIpc,
            () => {
              if (startupWindow && !startupWindow.isDestroyed()) startupWindow.destroy()
            },
            () => app.quit()
          ]) {
            try {
              cleanup()
            } catch (error) {
              log.warn('Startup shell cleanup failed', diagnosticErrorFields(error))
            }
          }
        }
      })
    },
    // Warn (rather than silently tear down) if the user tries to quit mid data-root migration. Installed
    // BEFORE the lifecycle so its before-quit runs first: a migration it cancels leaves
    // event.defaultPrevented set, which the lifecycle's quit cleanup honors.
    installMigrationQuitGuard: (ctx) =>
      ctx.installMigrationQuitGuard(app, undefined, ctx.translate),
    // Install the tray, first window, and the quit/activate/window-all-closed handlers. shutdownBackends
    // is bound with the live backend handles; the agent teardown latches shutting-down and awaits the
    // process tree so a Windows taskkill /T completes before app.exit.
    installAppLifecycle: (ctx) => {
      const lifecycle = ctx.installAppLifecycle({
        app,
        createMainWindow: ctx.createMainWindow,
        configureMainWindow: ctx.configureMainWindow,
        initialWindow: ctx.startupWindow,
        createTray: (handlers) => {
          const webPort = ctx.webController.runningPort()
          const headlessWeb = ctx.webMode.headless && webPort !== undefined
          const tray = ctx.createAppTray({
            iconPath: trayIconPath,
            variantIconPaths: trayVariantIconPaths,
            initialVariant:
              ctx.appIconControllerBox.current?.getVariant() ?? ctx.getAppIconVariant(),
            translate: ctx.translate,
            templateIconPath: process.platform === 'darwin' ? trayMacTemplate : undefined,
            ...handlers,
            ...(headlessWeb
              ? {
                  headless: true,
                  onOpenWeb: async () => {
                    const { shell } = await import('electron')
                    await shell.openExternal(await ctx.buildAuthenticatedWebUrl(webPort))
                  },
                  onCopyWebUrl: async () => {
                    const { clipboard } = await import('electron')
                    clipboard.writeText(await ctx.buildAuthenticatedWebUrl(webPort))
                  }
                }
              : {})
          })
          // Publish the tray so a later settings change can restyle it (onAppIconVariantChanged).
          ctx.appTrayBox.current = tray
          return tray
        },
        isMigrationInProgress: ctx.isMigrationInProgress,
        beforeExit: async () => {
          const { completeMacInstallationHandoff } = await import('./mac-installation')
          completeMacInstallationHandoff()
        },
        quit: () => app.quit(),
        countWindows: () => BrowserWindow.getAllWindows().length,
        createInitialWindow: !ctx.webMode.headless,
        bindSystemShutdownWindow,
        detectActiveSessions: ctx.detectActiveSessions,
        hasActiveReviewerWork: ctx.hasActiveReviewerWork,
        getActiveSettingsInstallId: ctx.getActiveSettingsInstallId,
        holdSettingsInstallAdmission: ctx.holdSettingsInstallAdmission,
        prepareForQuit: ctx.prepareForQuit,
        abortQuitPreparation: (reason) => {
          ctx.abortQuitPreparation()
          ctx.notifySessionPersistenceFlushAborted(
            () => ctx.mainWindowGetterBox.current?.(),
            reason
          )
        },
        flushSessionPersistence: ctx.createSessionPersistenceFlush(() =>
          ctx.mainWindowGetterBox.current?.()
        ),
        createConfirmClose: ctx.createConfirmClose,
        onAppearanceChanged: (appearance) =>
          ctx.appIconControllerBox.current?.setAppearance(appearance),
        log: ctx.log,
        flushLogs,
        // Application composition owns the one bounded ACP/Notebook shutdown. Startup failures
        // after composition and ordinary lifecycle shutdown reuse this exact ordered owner.
        shutdownBackends: ctx.shutdownApplicationSurfaces
      })
      const { showMainWindow, getMainWindow, isMainWindowHidden, onSystemShutdown } = lifecycle
      openPackageWindow = showMainWindow

      // Window lifecycle now exists: expose it to the restored controller, reapply any Windows
      // overlay to the first window, then attach completion/focus/window-recreation events.
      ctx.mainWindowGetterBox.current = getMainWindow
      ctx.notificationInbox.refreshBadge()

      const desktopAttention = ctx.createDesktopAttentionController({
        platform: process.platform,
        headless: ctx.webMode.headless,
        isAppFocused: () => BrowserWindow.getAllWindows().some((window) => window.isFocused()),
        isMainWindowHidden,
        getMainWindow,
        ...(process.platform === 'darwin' ? { dock: app.dock } : {}),
        onError: (error) => ctx.log.warn('desktop attention failed', error)
      })
      ctx.wireNotificationInboxController({
        app,
        controller: ctx.notificationInbox
      })
      ctx.wireDesktopAttention({
        app,
        taskNotifications: ctx.taskNotifications,
        controller: desktopAttention
      })

      // Clicking a task notification surfaces the app and records which conversation to open. The
      // renderer pulls the target once its sessions are hydrated (take-pending-open-session), so a
      // click that recreates the window cannot lose the navigation — the send below is only a
      // nudge for an already-running renderer and may safely be lost otherwise.
      ctx.taskNotifications.setActivationHandler((sessionId) => {
        const window = showMainWindow()
        if (!sessionId) return

        // The renderer pulls the click target once its sessions are hydrated.
        ctx.taskNotifications.setPendingOpenSession(sessionId)
        window.webContents.send('notifications:open-session')
      })

      // Route each second launch by its forwarded argv (see second-instance-router): a CLI
      // `open-science start` forwards --serve/--open-science-headless → start the web service on demand
      // here (attached); a plain re-launch (double-click) → surface the existing window as before.
      const onSecondInstance = (argv: string[]): void =>
        ctx.routeSecondInstance(argv, {
          ensureWebService: ctx.webController.ensureStarted,
          showMainWindow,
          onError: (error) => ctx.log.error('on-demand web service start failed', error)
        })
      preStartupSecondInstanceRelay.bind(onSecondInstance)
      return { onSecondInstance, onSystemShutdown }
    },
    cleanupAfterStartupFailure: async (ctx) => {
      await ctx.shutdownApplicationSurfaces()
    },
    markReady: (ctx) => {
      ctx.databaseStartupOwner.complete()
      ctx.databaseStartupQuitGuard.release()
      reportPackageOverflow = () => ctx.openSessionPackageFile(null)
      packageFiles.bind((path) => {
        openPackageWindow?.()
        ctx.openSessionPackageFile(path)
      })
    }
  })
}

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.

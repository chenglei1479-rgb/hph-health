import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, posix, win32 } from 'node:path'

import { describe, expect, it } from 'vitest'

import {
  caBundleEnv,
  createFromLockArgv,
  createFromPackagesArgv,
  installFromLockArgv,
  installArgv,
  listArgv,
  micromambaSpawnEnv,
  normalizeExplicitLock,
  resolveMicromamba,
  resolveMicromambaLocations
} from './micromamba'

describe('micromamba argv builders', () => {
  it('createFromLockArgv is the offline unified form (no channel)', () => {
    const argv = createFromLockArgv(
      '/mm',
      '/root',
      '/root/envs/default-python',
      '/res/default-python.lock'
    )
    expect(argv).toEqual([
      '/mm',
      '--no-rc',
      'create',
      '-p',
      '/root/envs/default-python',
      '--file',
      '/res/default-python.lock',
      '--offline',
      '-y',
      '--root-prefix',
      '/root'
    ])
    expect(argv.join(' ')).not.toContain('conda-forge')
  })

  it('can create from an imported explicit lock with network access', () => {
    const argv = createFromLockArgv('/mm', '/root', '/root/envs/repro-lock', '/tmp/lock', {
      offline: false
    })
    expect(argv).not.toContain('--offline')
    expect(argv).toEqual(
      expect.arrayContaining(['--file', '/tmp/lock', '-p', '/root/envs/repro-lock'])
    )
  })

  it('createFromPackagesArgv is the online channel form with packages last', () => {
    const argv = createFromPackagesArgv(
      '/mm',
      '/root',
      '/root/envs/default-r',
      ['conda-forge'],
      ['r-base', 'r-irkernel']
    )
    expect(argv).toEqual([
      '/mm',
      '--no-rc',
      'create',
      '--root-prefix',
      '/root',
      '--prefix',
      '/root/envs/default-r',
      '-y',
      '-c',
      'conda-forge',
      'r-base',
      'r-irkernel'
    ])
    expect(argv.join(' ')).not.toContain('--offline')
  })

  it('expands multiple channels into repeated -c flags in priority order', () => {
    const argv = installArgv(
      '/mm',
      '/root',
      '/p',
      ['conda-forge', 'bioconda'],
      ['bioconductor-deseq2']
    )
    // conda-forge listed first (highest strict priority), bioconda next.
    expect(argv.join(' ')).toContain('-c conda-forge -c bioconda bioconductor-deseq2')
  })

  it('installArgv is the additive form', () => {
    const argv = installArgv(
      '/mm',
      '/root',
      '/root/envs/default-python',
      ['conda-forge'],
      ['openpyxl']
    )
    expect(argv).toEqual([
      '/mm',
      '--no-rc',
      'install',
      '--root-prefix',
      '/root',
      '--prefix',
      '/root/envs/default-python',
      '-y',
      '-c',
      'conda-forge',
      'openpyxl'
    ])
  })

  it('listArgv is the read-only JSON inventory form (no channels, no -y)', () => {
    const argv = listArgv('/mm', '/root', '/root/envs/default-python')
    expect(argv).toEqual([
      '/mm',
      '--no-rc',
      'list',
      '--root-prefix',
      '/root',
      '--prefix',
      '/root/envs/default-python',
      '--json'
    ])
    expect(argv).not.toContain('-y')
    expect(argv).not.toContain('-c')
  })

  it('installFromLockArgv applies an exact lock additively without a channel solve', () => {
    const argv = installFromLockArgv(
      '/mm',
      '/root',
      '/root/envs/default-python',
      '/root/packs/2/linux-64/python-3.12/python-3.12.lock'
    )
    expect(argv).toEqual([
      '/mm',
      '--no-rc',
      'install',
      '-p',
      '/root/envs/default-python',
      '--file',
      '/root/packs/2/linux-64/python-3.12/python-3.12.lock',
      '--offline',
      '-y',
      '--root-prefix',
      '/root'
    ])
    expect(argv).not.toContain('-c')
  })
})

describe('normalizeExplicitLock', () => {
  it('prepends @EXPLICIT and keeps only package URL lines', () => {
    const raw = [
      '# This file may be used to create an environment using:',
      '# platform: osx-arm64',
      'https://conda.anaconda.org/conda-forge/noarch/numpy-1.0.conda#abc123',
      '  https://conda.anaconda.org/conda-forge/osx-arm64/python-3.12.conda#def456  ',
      'not a url line'
    ].join('\n')
    expect(normalizeExplicitLock(raw)).toBe(
      [
        '@EXPLICIT',
        'https://conda.anaconda.org/conda-forge/noarch/numpy-1.0.conda#abc123',
        'https://conda.anaconda.org/conda-forge/osx-arm64/python-3.12.conda#def456'
      ].join('\n') + '\n'
    )
  })

  it('handles input with no url lines', () => {
    expect(normalizeExplicitLock('# nothing here\n')).toBe('@EXPLICIT\n')
  })

  it('handles empty input', () => {
    expect(normalizeExplicitLock('')).toBe('@EXPLICIT\n')
  })
})

describe('resolveMicromamba', () => {
  it('prefers the OPEN_SCIENCE_MICROMAMBA_BIN override when it is a file', () => {
    const dir = mkdtempSync(join(tmpdir(), 'os-mm-'))
    const bin = join(dir, 'micromamba')
    writeFileSync(bin, 'x')
    expect(resolveMicromamba({ env: { OPEN_SCIENCE_MICROMAMBA_BIN: bin } })).toBe(bin)
  })

  it('ignores the override when it does not point at a real file', () => {
    const resources = mkdtempSync(join(tmpdir(), 'os-res-'))
    const name = process.platform === 'win32' ? 'micromamba.exe' : 'micromamba'
    writeFileSync(join(resources, name), 'x')
    expect(
      resolveMicromamba({
        env: { OPEN_SCIENCE_MICROMAMBA_BIN: '/no/such/bin' },
        resourcesPath: resources
      })
    ).toBe(join(resources, name))
  })

  it('falls back to the bundled resource binary', () => {
    const resources = mkdtempSync(join(tmpdir(), 'os-res-'))
    const name = process.platform === 'win32' ? 'micromamba.exe' : 'micromamba'
    writeFileSync(join(resources, name), 'x')
    expect(resolveMicromamba({ env: {}, resourcesPath: resources })).toBe(join(resources, name))
  })

  it('falls back to the storage-root runtime binary under home', () => {
    const home = mkdtempSync(join(tmpdir(), 'os-home-'))
    const name = process.platform === 'win32' ? 'micromamba.exe' : 'micromamba'
    const runtimeDir = join(home, '.open-science', 'runtime', 'micromamba', 'bin')
    mkdirSync(runtimeDir, { recursive: true })
    writeFileSync(join(runtimeDir, name), 'x')
    expect(resolveMicromamba({ env: {}, resourcesPath: '/no/such/dir', home })).toBe(
      join(runtimeDir, name)
    )
  })

  it('falls back to PATH when nothing else resolves', () => {
    const dir = mkdtempSync(join(tmpdir(), 'os-path-'))
    const name = process.platform === 'win32' ? 'micromamba.exe' : 'micromamba'
    writeFileSync(join(dir, name), 'x')
    expect(
      resolveMicromamba({
        env: { PATH: dir },
        resourcesPath: '/no/such/dir',
        home: '/no/such/home'
      })
    ).toBe(join(dir, name))
  })

  it.each([
    ['win32', ';', 'micromamba.exe'],
    ['darwin', ':', 'micromamba'],
    ['linux', ':', 'micromamba']
  ] as const)(
    'uses the %s PATH delimiter and preserves candidate order',
    (platform, separator, name) => {
      const root = mkdtempSync('os-mm-path-')
      try {
        const first = join(root, 'first')
        const second = join(root, 'second')
        mkdirSync(first)
        mkdirSync(second)
        writeFileSync(join(first, name), 'first')
        writeFileSync(join(second, name), 'second')

        const paths = resolveMicromambaLocations({
          platform,
          env: { PATH: [first, second].join(separator) },
          resourcesPath: join(root, 'missing-resources'),
          home: join(root, 'missing-home')
        })

        expect(paths).toEqual([
          { kind: 'path', path: join(first, name) },
          { kind: 'path', path: join(second, name) }
        ])
      } finally {
        rmSync(root, { recursive: true, force: true })
      }
    }
  )

  it('returns undefined when nothing resolves', () => {
    expect(
      resolveMicromamba({ env: {}, resourcesPath: '/no/such/dir', home: '/no/such/home' })
    ).toBeUndefined()
  })
})

describe('caBundleEnv', () => {
  it('fans one PEM path out to every download tool CA var', () => {
    expect(caBundleEnv('/ca.pem')).toEqual({
      CONDA_SSL_VERIFY: '/ca.pem',
      SSL_CERT_FILE: '/ca.pem',
      REQUESTS_CA_BUNDLE: '/ca.pem',
      PIP_CERT: '/ca.pem',
      CURL_CA_BUNDLE: '/ca.pem'
    })
  })

  it('is empty when no bundle is set', () => {
    expect(caBundleEnv(undefined)).toEqual({})
    expect(caBundleEnv('')).toEqual({})
  })
})

describe('micromambaSpawnEnv', () => {
  it('keeps the Windows package cache ASCII-only for a non-ASCII user profile', () => {
    const env = micromambaSpawnEnv('C:\\Users\\甲乙\\OpenScience\\runtime', undefined, {
      platform: 'win32',
      env: {
        USERNAME: '甲乙',
        USERPROFILE: 'C:\\Users\\甲乙',
        PUBLIC: 'C:\\Users\\Public'
      },
      canonicalize: (path) => win32.normalize(path),
      prepare: (path) => win32.normalize(path),
      verifyOwnership: () => true
    })

    expect(env.CONDA_PKGS_DIRS).toMatch(/^C:\\Deep Research AgentTmp\\m-[0-9a-hjkmnp-tv-z]{8}$/)
  })

  it('cleans inherited conda/mamba values before injecting the Windows app cache and CA vars', () => {
    const env = micromambaSpawnEnv('D:\\OpenScience\\runtime', '/ca.pem', {
      platform: 'win32',
      env: {
        PATH: 'C:\\Windows',
        CONDA_PKGS_DIRS: 'Z:\\hostile-cache',
        conda_prefix: 'Z:\\foreign-env',
        MAMBA_ROOT_PREFIX: 'Z:\\foreign-root',
        SSL_CERT_FILE: 'Z:\\old-ca'
      },
      selectCache: () => ({ path: 'D:\\osp1234567890', lockKey: 'd:\\osp1234567890' })
    })

    expect(env).toMatchObject({
      PATH: 'C:\\Windows',
      CONDA_PKGS_DIRS: 'D:\\osp1234567890',
      CONDA_SSL_VERIFY: '/ca.pem',
      SSL_CERT_FILE: '/ca.pem',
      REQUESTS_CA_BUNDLE: '/ca.pem',
      PIP_CERT: '/ca.pem',
      CURL_CA_BUNDLE: '/ca.pem'
    })
    expect(env.conda_prefix).toBeUndefined()
    expect(env.MAMBA_ROOT_PREFIX).toBe('D:\\OpenScience\\runtime')
  })

  it.each(['darwin', 'linux', 'win32'] as const)(
    'confines all managed Micromamba state to the runtime on %s',
    (platform) => {
      const root = platform === 'win32' ? 'D:\\OpenScience\\runtime' : '/runtime'
      const runtimePath = platform === 'win32' ? win32 : posix
      const cache = runtimePath.join(root, 'coordinated-pkgs')
      const home = runtimePath.join(root, 'home')
      const env = micromambaSpawnEnv(root, '/ca.pem', {
        platform,
        env: {
          HOME: '/host-home',
          HTTPS_PROXY: 'http://proxy.test:8080',
          USERPROFILE: 'C:\\Users\\host-user',
          CONDA_PKGS_DIRS: '/existing',
          CONDA_ENVS_PATH: '/existing-envs',
          MAMBA_ROOT_PREFIX: '/existing-root',
          R_USER: '/host-r-user',
          R_LIBS: '/host-r-libs',
          R_LIBS_USER: '/host-r-user-library',
          R_LIBS_SITE: '/host-r-site-library'
        },
        selectCache: () => ({ path: cache, lockKey: cache.toLowerCase() })
      })

      expect(env.HOME).toBe(home)
      expect(env.HTTPS_PROXY).toBe('http://proxy.test:8080')
      expect(env.USERPROFILE).toBe(home)
      expect(env.MAMBA_ROOT_PREFIX).toBe(root)
      expect(env.CONDA_PKGS_DIRS).toBe(cache)
      expect(env.CONDA_ENVS_PATH).toBe(runtimePath.join(root, 'envs'))
      expect(env.CONDA_SSL_VERIFY).toBe('/ca.pem')
      expect(env.R_USER).toBeUndefined()
      expect(env.R_LIBS).toBeUndefined()
      expect(env.R_LIBS_USER).toBeUndefined()
      expect(env.R_LIBS_SITE).toBeUndefined()
    }
  )
})

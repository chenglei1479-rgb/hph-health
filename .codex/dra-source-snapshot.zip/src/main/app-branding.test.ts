import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

import { describe, expect, it } from 'vitest'

const projectRoot = resolve(__dirname, '../..')
const displayName = 'Deep Research Agent'
const appId = 'com.aipoch.medresearch-agent'

describe('app display branding', () => {
  it('uses the Deep Research Agent display name in shell and workspace surfaces', () => {
    const mainSource = readFileSync(resolve(projectRoot, 'src/main/index.ts'), 'utf8')
    const windowsSource = readFileSync(resolve(projectRoot, 'src/main/windows.ts'), 'utf8')
    const rendererHtmlSource = readFileSync(resolve(projectRoot, 'src/renderer/index.html'), 'utf8')
    const builderSource = readFileSync(resolve(projectRoot, 'electron-builder.yml'), 'utf8')
    const packageSource = readFileSync(resolve(projectRoot, 'package.json'), 'utf8')
    const appConfigSource = readFileSync(resolve(projectRoot, 'src/shared/app-config.ts'), 'utf8')
    // The product name now anchors the home screen brand (the workspace sidebar shows the project).
    const homePageSource = readFileSync(
      resolve(projectRoot, 'src/renderer/src/pages/home/HomePage.tsx'),
      'utf8'
    )

    expect(mainSource).toContain(`const APP_NAME = '${displayName}'`)
    expect(windowsSource).toContain(`title: '${displayName}'`)
    expect(rendererHtmlSource).toContain(`<title>${displayName}</title>`)
    expect(builderSource).toContain(`productName: ${displayName}`)
    expect(builderSource).toContain(`CFBundleName: ${displayName}`)
    // Finder uses the installation label; CFBundleName stays aligned with Electron Helpers.
    expect(builderSource).toContain('CFBundleDisplayName: Deep Research Agent')
    expect(builderSource).toContain('name: Deep Research Agent.app')
    expect(packageSource).toContain(`"productName": "${displayName}"`)
    expect(appConfigSource).toContain(`name: '${displayName}'`)
    expect(homePageSource).toContain('APP.name')
  })

  it('uses the stable app identifier for packaged and window integration metadata', () => {
    const mainSource = readFileSync(resolve(projectRoot, 'src/main/index.ts'), 'utf8')
    const builderSource = readFileSync(resolve(projectRoot, 'electron-builder.yml'), 'utf8')

    expect(mainSource).toContain(`const APP_USER_MODEL_ID = '${appId}'`)
    expect(builderSource).toContain(`appId: ${appId}`)
  })

  it('opens tall enough to show the complete first-run environment summary', () => {
    const windowsSource = readFileSync(resolve(projectRoot, 'src/main/windows.ts'), 'utf8')

    expect(windowsSource).toContain('height: 960')
    expect(windowsSource).toContain('minHeight: 720')
  })

  it('awaits Electron readiness inside the startup promise chain', () => {
    const mainSource = readFileSync(resolve(projectRoot, 'src/main/index.ts'), 'utf8')

    expect(mainSource).toContain('await app.whenReady()')
    expect(mainSource).not.toContain('app.whenReady().then')
  })
})

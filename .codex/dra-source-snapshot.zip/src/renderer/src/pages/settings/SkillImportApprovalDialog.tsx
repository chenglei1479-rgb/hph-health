import { ErrorNotice } from '@/components/error-notice'
import { InlineNotice } from '@/components/ui/inline-notice'
import { useState } from 'react'
import { PackagePlus, X } from 'lucide-react'
import * as Dialog from '@/components/ui/dialog'
import { Trans, useTranslation } from 'react-i18next'

import type {
  ConversationSkillImportApprovalRequest,
  ConversationSkillImportApprovalResponse,
  ConversationSkillImportSelection
} from '../../../../shared/settings'
import { Button } from '@/components/ui/button'
import {
  dialogBodyClassName,
  dialogCloseButtonClassName,
  dialogCancelButtonClassName,
  dialogDescriptionClassName,
  dialogFooterClassName,
  dialogHeaderClassName,
  dialogOverlayClassName,
  dialogPanelClassName,
  dialogTitleClassName
} from '@/components/ui/dialog-chrome'
import { cn } from '@/lib/utils'
import { useSkillImportStore } from '@/stores/skill-import-store'
import { SkillImportCandidatePreview, SkillReplacementSummary } from './SkillImportCandidatePreview'
import { useSkillImportCandidatePreview } from './useSkillImportCandidatePreview'

type SkillImportApprovalRequestDialogProps = {
  active: boolean
  onClose: () => void
  request: ConversationSkillImportApprovalRequest
  respond: (response: ConversationSkillImportApprovalResponse) => Promise<void>
}

const SkillImportApprovalRequestDialog = ({
  active,
  onClose,
  request,
  respond
}: SkillImportApprovalRequestDialogProps): React.JSX.Element => {
  const { t } = useTranslation()
  const { t: tCommon } = useTranslation()
  const [selected, setSelected] = useState<Set<string>>(() =>
    request.source.kind === 'github'
      ? new Set(
          request.previews
            .filter((candidate) => !candidate.alreadyImported)
            .map((candidate) => candidate.subPath)
        )
      : request.previews.length === 1
        ? new Set([request.previews[0].subPath])
        : new Set()
  )
  const responding = useSkillImportStore((state) => state.respondingIds.includes(request.id))
  const [responseFailed, setResponseFailed] = useState(false)
  const submit = async (response: ConversationSkillImportApprovalResponse): Promise<void> => {
    if (responding) return
    setResponseFailed(false)
    try {
      await respond(response)
    } catch {
      setResponseFailed(true)
    }
  }
  const candidatePreview = useSkillImportCandidatePreview()

  const toggle = (subPath: string): void => {
    setSelected((current) => {
      const next = new Set(current)
      if (next.has(subPath)) next.delete(subPath)
      else next.add(subPath)
      return next
    })
  }
  const allSelected = request.previews.length > 0 && selected.size === request.previews.length
  const toggleAll = (): void =>
    setSelected(() =>
      allSelected ? new Set() : new Set(request.previews.map((candidate) => candidate.subPath))
    )
  const invertSelection = (): void =>
    setSelected((current) => {
      const next = new Set<string>()
      for (const candidate of request.previews) {
        if (!current.has(candidate.subPath)) next.add(candidate.subPath)
      }
      return next
    })
  const confirm = (): void => {
    const items: ConversationSkillImportSelection[] = request.previews
      .filter((candidate) => selected.has(candidate.subPath))
      .map((candidate) => ({
        subPath: candidate.subPath,
        ...(candidate.replaceableId ? { replaceId: candidate.replaceableId } : {})
      }))
    void submit({ id: request.id, items })
  }
  const count = selected.size
  const importLabel =
    request.source.kind === 'github'
      ? t('Import selected ({{count}})', { count })
      : count > 0
        ? t('Import {{count}} Skills', { defaultValue_one: 'Import {{count}} Skill', count })
        : t('Import selected')

  return (
    <>
      <Dialog.Root
        open={active}
        onOpenChange={(open) => {
          if (!open) onClose()
        }}
      >
        <Dialog.Portal>
          <Dialog.Overlay className={dialogOverlayClassName} />
          <Dialog.Content
            aria-busy={responding}
            onInteractOutside={(event) => event.preventDefault()}
            className={dialogPanelClassName(
              'flex max-h-[min(88vh,760px)] w-[min(620px,calc(100vw-2rem))] flex-col overflow-hidden p-0'
            )}
          >
            <div className={cn(dialogHeaderClassName, 'items-start justify-start')}>
              <PackagePlus className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <Dialog.Title className={dialogTitleClassName}>
                  {request.source.kind === 'github'
                    ? t('Import Skills from GitHub?')
                    : t('Import Skill package?')}
                </Dialog.Title>
                <Dialog.Description className={cn(dialogDescriptionClassName, 'text-xs')}>
                  {/* The source label is user data: interpolated, never translated. */}
                  <Trans
                    i18nKey="The agent requested an import from <name>{{source}}</name>. Review and choose exactly what Deep Research Agent may install."
                    values={{ source: request.source.label }}
                    components={{
                      name: <span className="break-all font-medium text-foreground" />
                    }}
                  />
                </Dialog.Description>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon-sm"
                aria-label={t('Close')}
                className={cn(dialogCloseButtonClassName, 'shrink-0')}
                onClick={onClose}
              >
                <X className="size-4" aria-hidden="true" />
              </Button>
            </div>

            <div className={cn(dialogBodyClassName, 'min-h-0 flex-1 overflow-y-auto py-3')}>
              <div className="flex items-center gap-3">
                <h3 className="text-sm font-semibold text-foreground">
                  {t('Found {{count}} skills', {
                    defaultValue_one: 'Found {{count}} skill',
                    count: request.previews.length
                  })}
                </h3>
                <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <input
                    type="checkbox"
                    aria-label={t('Select all')}
                    checked={allSelected}
                    onChange={toggleAll}
                    className="size-4 shrink-0"
                  />
                  {t('Select all')}
                </label>
                <Button type="button" variant="ghost" size="sm" onClick={invertSelection}>
                  {t('Invert')}
                </Button>
              </div>

              <ul className="mt-2 flex flex-col divide-y divide-border">
                {request.previews.map((candidate) => (
                  <li key={candidate.subPath} className="flex items-center gap-3 py-2.5">
                    <input
                      type="checkbox"
                      aria-label={t('Select {{name}}', {
                        name: candidate.name
                      })}
                      checked={selected.has(candidate.subPath)}
                      onChange={() => toggle(candidate.subPath)}
                      className="size-4 shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium text-foreground">
                        {candidate.name}
                      </div>
                      {candidate.replacement ? (
                        <SkillReplacementSummary replacement={candidate.replacement} />
                      ) : candidate.replaceableId ? (
                        <p className="text-xs text-muted-foreground">
                          {t(
                            'The installed folder will be replaced, including local edits and files absent from this package. Cancel to keep the current copy.'
                          )}
                        </p>
                      ) : null}
                      <div className="truncate text-xs text-muted-foreground">
                        {candidate.description || candidate.subPath}
                      </div>
                    </div>
                    {candidate.alreadyImported ? (
                      <span className="shrink-0 rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                        {request.source.kind === 'github' ? t('Imported') : t('Already imported')}
                      </span>
                    ) : candidate.replaceableId ? (
                      <span className="shrink-0 rounded-full bg-status-warning-surface/10 dark:bg-status-warning-dark-surface/10 px-2 py-0.5 text-xs text-status-warning-foreground dark:text-status-warning-dark-foreground">
                        {t('Updates existing')}
                      </span>
                    ) : null}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() =>
                        candidatePreview.openPreview(() => {
                          if (candidate.githubUrl) {
                            return window.api.settings.previewGitHubSkill({
                              url: candidate.githubUrl
                            })
                          }
                          if (candidate.previewError) throw new Error(candidate.previewError)
                          return {
                            name: candidate.name,
                            description: candidate.description,
                            sourceLabel: `${request.source.label} · ${candidate.subPath}`,
                            metadata: candidate.metadata,
                            body: candidate.body,
                            replacement: candidate.replacement,
                            files: candidate.files
                          }
                        })
                      }
                    >
                      {t('Preview')}
                    </Button>
                  </li>
                ))}
              </ul>

              {request.skipped.length > 0 ? (
                <InlineNotice className="mt-3">
                  <div className="font-medium text-foreground">{t('Not importable')}</div>
                  {/* item.source and item.reason are backend-supplied and pass through verbatim. */}
                  <ul className="mt-1 list-disc space-y-1 pl-4">
                    {request.skipped.map((item) => (
                      <li key={`${item.source}:${item.reason}`}>
                        {item.source}: {item.reason}
                      </li>
                    ))}
                  </ul>
                </InlineNotice>
              ) : null}
            </div>

            {responseFailed ? (
              <ErrorNotice
                inline
                tone="red"
                className="px-5 pb-3"
                role="alert"
                title={t('Could not send your response.')}
                description={t('Try again when the connection is available, or close this dialog.')}
              />
            ) : null}
            <div className={dialogFooterClassName}>
              <Button
                type="button"
                variant="ghost"
                className={dialogCancelButtonClassName}
                disabled={responding}
                onClick={() => void submit({ id: request.id, cancelled: true })}
              >
                {tCommon('Cancel')}
              </Button>
              <Button
                type="button"
                variant={request.source.kind === 'github' ? 'outline' : 'default'}
                disabled={responding || count === 0}
                onClick={confirm}
              >
                {importLabel}
              </Button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
      <SkillImportCandidatePreview
        {...candidatePreview.previewProps}
        open={active && candidatePreview.previewProps.open}
      />
    </>
  )
}

export function SkillImportApprovalDialog({
  active = true,
  blockedSessionIds
}: {
  active?: boolean
  blockedSessionIds?: ReadonlySet<string>
}): React.JSX.Element | null {
  const request = useSkillImportStore((state) =>
    state.pending.find(
      (candidate) =>
        !state.closedIds.includes(candidate.id) && !blockedSessionIds?.has(candidate.sessionId)
    )
  )
  const respond = useSkillImportStore((state) => state.respond)
  const close = useSkillImportStore((state) => state.close)

  return request ? (
    <SkillImportApprovalRequestDialog
      key={request.id}
      active={active}
      onClose={() => close(request.id)}
      request={request}
      respond={respond}
    />
  ) : null
}
